def helloer_handler(event, context):
    return {
        "statusCode": 200,
        "body": "Hello from Python Lambda!"
    }
